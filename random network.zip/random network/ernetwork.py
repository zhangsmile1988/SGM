# -*- coding: utf-8 -*-
"""
Created on Tue May 28 11:36:41 2024

@author: lenovo
"""
import networkx as nx
import matplotlib.pyplot as plt

# 随机网络
randomGraph = nx.gnp_random_graph(2000, 0.004)

# 绘制网络图
nx.draw(randomGraph, with_labels=True)
plt.show()

# 将网络边写入文件
with open('ernetwork2000-0.004.txt', "w") as f:
    for u, v in randomGraph.edges():
        f.write(f"{u} {v}\n") 
f.close()