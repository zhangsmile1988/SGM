# -*- coding: utf-8 -*-
"""
Created on Sat Jun  8 20:29:07 2024

@author: lenovo
"""
import snap
import random
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from collections import Counter
import math
from scipy.stats import linregress  # 导入线性回归库 

# 生成无标度网络
G = snap.GenRndPowerLaw(2000, 2.5) 

# 获取节点数和边数
print(f"节点数：{G.GetNodes()}")
print(f"边数：{G.GetEdges()}")

# 将网络边写入文件
with open('snap-2000,2.5.txt', "w") as f:
  for EI in G.Edges():
     f.write(f"{EI.GetSrcNId()} {EI.GetDstNId()}\n") 
f.close()

# 将 SNAP 网络转换为 NetworkX 网络
nx_G = nx.Graph()
for NI in G.Nodes():
  node_id = NI.GetId()
  nx_G.add_node(node_id)
for EI in G.Edges():
  src_id = EI.GetSrcNId()
  dst_id = EI.GetDstNId()
  nx_G.add_edge(src_id, dst_id)

# 计算核心度
c = nx.core_number(nx_G)
print("核心度:", c)

# 计算度分布
dd = nx_G.degree(nx_G)
print("度:", dd)
dx = dict(dd)
print("度:", dx)

# 绘制网络图
plt.figure(figsize=(15, 15))
nx.draw(nx_G, with_labels=True, node_size=20)
plt.show()
